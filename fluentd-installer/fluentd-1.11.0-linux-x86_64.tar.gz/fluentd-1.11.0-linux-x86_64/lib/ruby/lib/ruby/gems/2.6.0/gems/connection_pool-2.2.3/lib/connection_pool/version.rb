class ConnectionPool
  VERSION = "2.2.3"
end
