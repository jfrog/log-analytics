# More logical way to require 'rest-client'
require File.dirname(__FILE__) + '/restclient'
